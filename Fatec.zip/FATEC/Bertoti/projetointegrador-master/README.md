# projetointegrador

Além do código deste repositório, outro com funcionalidades comuns presentes em plataforma e etc com MVC e Rest e etc é:

https://github.com/giulianobertoti/skills_heroku

Aqui está um vídeo com uma explicação do ciclo de vida do desenvolvimento de software juntamente com codificação em Java (existem alguns conceitos interessantes de Engenharia de Software presentes nele)

https://drive.google.com/file/d/14Ag8I7cmzkdYyg53iVLRs1O26Sz-7kPe/view?usp=sharing


E aqui estão slides sobre ciclo de vida do desenvolvimento de software, processos, desenvolvimento e etc bem detalhado:

https://docs.google.com/presentation/d/1GMds68vXowb3h_GFtI3fwKeXJQQJjm7L-wL0BJhIfLI/edit?usp=sharing

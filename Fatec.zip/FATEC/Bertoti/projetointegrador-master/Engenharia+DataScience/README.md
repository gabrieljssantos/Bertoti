spark-heroku
============

Spark Heroku skeleton

To deploy your app

	heroku apps:create [your_app_name]
	git push heroku master
